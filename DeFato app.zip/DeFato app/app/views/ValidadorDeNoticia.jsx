import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator, ScrollView } from 'react-native';
import axios from 'axios';

export default function VerificadorIA() {
  const [texto, setTexto] = useState('');
  const [resposta, setResposta] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [modo, setModo] = useState('verificar');

  const enviarParaIA = async (tipo) => {
    setCarregando(true);
    setResposta(null);
    setModo(tipo);
    const prompt = tipo === 'verificar'
      ? `Leia a seguinte notícia e diga se é verdadeira ou falsa, explicando de forma breve:\n\n${texto}`
      : `Resuma a seguinte notícia em poucas linhas de forma clara:\n\n${texto}`;

    try {
      const response = await axios.post(
        'https://openrouter.ai/api/v1/chat/completions',
        {
          model: 'openai/gpt-3.5-turbo',
          messages: [
            {
              role: 'user',
              content: prompt,
            },
          ],
        },
        {
          headers: {
            Authorization: 'Bearer YOUR_API_KEY', // Substitua pela sua chave
            'Content-Type': 'application/json',
          },
        }
      );
      const content = response.data.choices[0].message.content;
      setResposta(content);
    } catch (error) {
      console.error(error);
      setResposta('Erro ao processar a notícia. Tente novamente.');
    }
    setCarregando(false);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: '#fff', padding: 20 }}>
      <Text style={{ fontSize: 22, fontWeight: 'bold', color: '#B00000', marginBottom: 20, textAlign: 'center' }}>
        Verificador de Notícias
      </Text>

      <TextInput
        multiline
        numberOfLines={6}
        placeholder="Cole o texto da notícia para verificação ou resumo..."
        placeholderTextColor="#777"
        value={texto}
        onChangeText={setTexto}
        style={{
          backgroundColor: '#fff',
          borderRadius: 12,
          padding: 16,
          borderWidth: 1,
          borderColor: '#ddd',
          textAlignVertical: 'top',
          fontSize: 16,
          marginBottom: 20,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.1,
          shadowRadius: 2,
          elevation: 3,
        }}
      />

      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <TouchableOpacity
          onPress={() => enviarParaIA('verificar')}
          disabled={carregando || texto.trim() === ''}
          style={{
            backgroundColor: '#B00000',
            paddingVertical: 14,
            borderRadius: 8,
            alignItems: 'center',
            flex: 1,
            marginRight: 10,
          }}
        >
          {carregando && modo === 'verificar' ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16 }}>
              Verificar
            </Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => enviarParaIA('resumir')}
          disabled={carregando || texto.trim() === ''}
          style={{
            backgroundColor: '#B00000',
            paddingVertical: 14,
            borderRadius: 8,
            alignItems: 'center',
            flex: 1,
            marginLeft: 10,
          }}
        >
          {carregando && modo === 'resumir' ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16 }}>
              Resumir
            </Text>
          )}
        </TouchableOpacity>
      </View>

      {resposta && (
        <View style={{ 
          backgroundColor: '#f8f8f8', 
          padding: 16, 
          borderRadius: 8,
          marginTop: 20,
          borderLeftWidth: 4,
          borderLeftColor: '#B00000'
        }}>
          <Text style={{ 
            fontSize: 16, 
            color: '#333',
            lineHeight: 24
          }}>
            {resposta}
          </Text>
        </View>
      )}
    </ScrollView>
  );
}
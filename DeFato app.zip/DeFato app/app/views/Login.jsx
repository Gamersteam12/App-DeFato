import React, { useState } from 'react';
import {
  View,
  TextInput,
  Button,
  Alert,
  StyleSheet,
  Text,
  ActivityIndicator,
} from 'react-native';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../services/firebaseConfig';
import { doc, getDoc } from 'firebase/firestore';
import { useRouter } from 'expo-router';

export default function Login() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [carregando, setCarregando] = useState(false);
  const router = useRouter();

  const logar = async () => {
    if (!email || !senha) {
      Alert.alert('Erro', 'Preencha todos os campos.');
      return;
    }

    setCarregando(true);

    try {
      // 1. Login no Firebase Auth
      const userCredential = await signInWithEmailAndPassword(auth, email, senha);
      const user = userCredential.user;

      // 2. Obter dados do Firestore
      const userDocRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);

      if (!userDoc.exists()) {
        Alert.alert('Erro', 'Dados do usuário não encontrados no Firestore.');
        return;
      }

      const userData = userDoc.data();

      // 3. Verificar se o cadastro foi aprovado
      if (userData.status !== true) {
        Alert.alert('Acesso negado', 'Seu cadastro ainda está em análise.');
        return;
      }

      // 4. Redirecionar com base no papel do usuário
      switch (userData.role) {
        case 'jornalista':
          router.replace('/TelaPublicar'); // ou '/TelaBarViralidade' se for o nome real
          break;
        case 'administrador':
          router.replace('/TelaAprovacoes');
          break;
        case 'editor':
          router.replace('/ManchetesScreen');
          break;
        default:
          router.replace('/UltimasNoticias');
      }

    } catch (error) {
      let mensagem = '';
      switch (error.code) {
        case 'auth/invalid-email':
          mensagem = 'Email inválido';
          break;
        case 'auth/user-disabled':
          mensagem = 'Usuário desativado';
          break;
        case 'auth/user-not-found':
        case 'auth/wrong-password':
          mensagem = 'Email ou senha incorretos';
          break;
        default:
          mensagem = 'Erro ao fazer login. Tente novamente.';
      }
      Alert.alert('Erro', mensagem);
    } finally {
      setCarregando(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Login</Text>

      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
        style={styles.input}
      />
      <TextInput
        placeholder="Senha"
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
        style={styles.input}
      />

      {carregando ? (
        <ActivityIndicator size="large" color="#C8102E" />
      ) : (
        <Button title="Entrar" onPress={logar} color="#C8102E" />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#C8102E',
    textAlign: 'center',
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    marginBottom: 20,
    fontSize: 16,
    padding: 10,
  },
});

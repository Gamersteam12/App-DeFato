import React, { useState } from 'react';
import { View, TextInput, Button, Alert, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { createUserWithEmailAndPassword, sendEmailVerification } from 'firebase/auth';
import { auth } from '../services/firebaseConfig';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../services/firebaseConfig';
import { useRouter } from 'expo-router';

export default function Cadastro() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [tipo, setTipo] = useState('jornalista'); // ou 'administrador'
  const router = useRouter();

  const cadastrarUsuario = async () => {
    if (!email || !senha) {
      Alert.alert('Erro', 'Preencha todos os campos.');
      return;
    }

    try {
      const credenciais = await createUserWithEmailAndPassword(auth, email, senha);

      // Envia email de verificação
      await sendEmailVerification(credenciais.user);

      // Salva dados do usuário no Firestore, sem senha
      await addDoc(collection(db, 'usuario'), {
        uid: credenciais.user.uid,
        email: email,
        tipo: tipo,
        status: 'pendente',
      });

      Alert.alert(
        'Cadastro enviado',
        'Verifique seu email para ativar a conta. Aguarde a aprovação do administrador.'
      );
      router.push('/views/Login');
    } catch (error) {
      Alert.alert('Erro ao cadastrar', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Cadastro</Text>

      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
        style={styles.input}
      />
      <TextInput
        placeholder="Senha"
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
        style={styles.input}
      />

      <View style={styles.tipoContainer}>
        <TouchableOpacity onPress={() => setTipo('jornalista')}>
          <Text style={[styles.tipoBotao, tipo === 'jornalista' && styles.tipoSelecionado]}>Jornalista</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setTipo('administrador')}>
          <Text style={[styles.tipoBotao, tipo === 'administrador' && styles.tipoSelecionado]}>Administrador</Text>
        </TouchableOpacity>
      </View>

      <Button title="Cadastrar" onPress={cadastrarUsuario} color="#C8102E" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#C8102E',
    textAlign: 'center',
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    marginBottom: 20,
    fontSize: 16,
    padding: 10,
  },
  tipoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 30,
  },
  tipoBotao: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#C8102E',
    borderRadius: 5,
    color: '#C8102E',
  },
  tipoSelecionado: {
    backgroundColor: '#C8102E',
    color: '#fff',
  },
});

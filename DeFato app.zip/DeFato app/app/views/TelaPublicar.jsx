import React, { useState, useEffect, useRef, useCallback } from 'react'; // Adicionado useCallback
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  ScrollView,
  Animated,
  Image,
  TouchableOpacity,
  Alert,
  ActivityIndicator, // Adicionado
} from 'react-native';
import { db, storage } from '../services/firebaseConfig'; // Ajuste o caminho se necessário
import { getAuth, onAuthStateChanged } from 'firebase/auth'; // Adicionado onAuthStateChanged
import * as ImagePicker from 'expo-image-picker';
import { collection, addDoc, serverTimestamp, doc, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useRouter } from 'expo-router'; // Adicionado para navegação
import frequenciasJson from '../../assets/palavras-chave.json'; // Ajuste o caminho se necessário

const normalizeString = (str) =>
  str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export default function TelaBarViralidade() {
  const [titulo, setTitulo] = useState('');
  const [conteudo, setConteudo] = useState('');
  const [imagem, setImagem] = useState(null);
  const [autorNome, setAutorNome] = useState('');
  const [freqNormalized, setFreqNormalized] = useState({});
  const [maxPontuacao, setMaxPontuacao] = useState(1);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregandoSubmit, setCarregandoSubmit] = useState(false);
  const [tipoUsuario, setTipoUsuario] = useState('');
  const animatedValue = useRef(new Animated.Value(0)).current;

  // Estados para controle de autenticação
  const [authVerificada, setAuthVerificada] = useState(false);
  const [usuarioAutenticado, setUsuarioAutenticado] = useState(false);

  const auth = getAuth();
  const router = useRouter(); // Hook do router

  // Efeito para verificar o estado de autenticação e carregar dados do usuário
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setUsuarioAutenticado(true);
        let nomeAutorDisplay = user.displayName || '';

        try {
          // Certifique-se que o nome da coleção é 'usuario' ou 'usuarios'
          const userDocRef = doc(db, 'usuario', user.uid); // Usando 'usuario' (singular)
          const userDoc = await getDoc(userDocRef);

          if (userDoc.exists()) {
            const userData = userDoc.data();
            setTipoUsuario(userData.tipo || 'jornalista');
            if (!nomeAutorDisplay && userData.nomeCompleto) {
              nomeAutorDisplay = userData.nomeCompleto;
            } else if (!nomeAutorDisplay && !userData.nomeCompleto && user.email) {
              nomeAutorDisplay = user.email.split('@')[0];
            }
          } else {
            console.warn("Usuário autenticado mas sem documento no Firestore:", user.uid);
            setTipoUsuario('jornalista'); // Padrão
            if (!nomeAutorDisplay && user.email) {
              nomeAutorDisplay = user.email.split('@')[0];
            }
          }
        } catch (error) {
          console.error("Erro ao carregar dados do usuário do Firestore:", error);
          setTipoUsuario('jornalista'); // Padrão em caso de erro
          if (!nomeAutorDisplay && user.email) {
            nomeAutorDisplay = user.email.split('@')[0];
          }
        }
        setAutorNome(nomeAutorDisplay);
      } else {
        setUsuarioAutenticado(false);
        setAutorNome('');
        setTipoUsuario('');
      }
      setAuthVerificada(true); // Marca que a verificação de autenticação foi concluída
    });

    return () => unsubscribe(); // Limpa a inscrição ao desmontar o componente
  }, [auth]); // Dependência do objeto auth

  // Normalização das palavras-chave (executa uma vez)
  useEffect(() => {
    const normalizedMap = {};
    let total = 0;
    Object.entries(frequenciasJson).forEach(([orig, peso]) => {
      const key = normalizeString(orig);
      normalizedMap[key] = peso;
      total += peso;
    });
    setFreqNormalized(normalizedMap);
    setMaxPontuacao(total > 0 ? total : 1); // Evita divisão por zero
  }, []);

  // Cálculo da pontuação de viralidade
  useEffect(() => {
    if (!usuarioAutenticado) return; // Não calcula se não estiver autenticado

    const normalizeAndSplit = (text) =>
      text
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .split(/\W+/)
        .filter((w) => w.length > 0);

    const titleWords = normalizeAndSplit(titulo);
    const contentWords = normalizeAndSplit(conteudo);

    let soma = 0;
    titleWords.forEach((palavra) => {
      if (freqNormalized[palavra] !== undefined) {
        soma += freqNormalized[palavra] * 2;
      }
    });
    contentWords.forEach((palavra) => {
      if (freqNormalized[palavra] !== undefined) {
        soma += freqNormalized[palavra];
      }
    });
    setPontuacao(soma);
  }, [titulo, conteudo, freqNormalized, usuarioAutenticado]);

  // Animação da barra de viralidade
  useEffect(() => {
    if (!usuarioAutenticado || maxPontuacao <= 0) return; // Não anima se não autenticado

    const basePercent = (pontuacao / maxPontuacao) * 100;
    const sensibilidade = 2.5;
    const novoPercent = Math.min(basePercent / sensibilidade, 100);

    Animated.timing(animatedValue, {
      toValue: novoPercent,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [pontuacao, maxPontuacao, animatedValue, usuarioAutenticado]);

  const larguraInterpolada = animatedValue.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  const barColor = animatedValue.interpolate({
    inputRange: [0, 30, 70, 100],
    outputRange: ['#e53935', '#e53935', '#f57c00', '#43a047'],
  });

  // Selecionar imagem da galeria
  const selecionarImagem = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets.length > 0) {
        setImagem(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Erro ao selecionar imagem:', error);
      Alert.alert('Erro', 'Não foi possível selecionar a imagem');
    }
  };

  // Função para publicar a notícia
  const publicar = async () => {
    if (!titulo.trim() || !conteudo.trim()) {
      Alert.alert('Erro', 'Título e conteúdo são obrigatórios!');
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      Alert.alert('Erro de Autenticação', 'Você precisa estar logado para publicar! Redirecionando para login.');
      router.push('/views/Login'); // Ajuste o caminho se necessário
      return;
    }

    setCarregandoSubmit(true);

    try {
      let imagemUrl = '';
      
      if (imagem) {
        const response = await fetch(imagem);
        const blob = await response.blob();
        const filename = `noticias/${user.uid}/${Date.now()}.jpg`;
        const storageRef = ref(storage, filename);
        await uploadBytes(storageRef, blob);
        imagemUrl = await getDownloadURL(storageRef);
      }

      await addDoc(collection(db, 'noticias'), {
        titulo: titulo.trim(),
        conteudo: conteudo.trim(),
        imagem: imagemUrl,
        pontuacao,
        criadoEm: serverTimestamp(),
        atualizadoEm: serverTimestamp(),
        visualizacoes: 0,
        curtidas: 0,
        autorId: user.uid,
        autorEmail: user.email,
        autorNome: autorNome.trim() || user.displayName || user.email?.split('@')[0] || 'Anônimo',
        autorTipo: tipoUsuario || 'jornalista',
        status: 'publicado',
        ...(tipoUsuario === 'admin' && { 
          oficial: true,
          prioridade: 1 
        })
      });

      Alert.alert('Sucesso', 'Notícia publicada com sucesso!');
      
      setTitulo('');
      setConteudo('');
      setImagem(null);
      setPontuacao(0);
    } catch (error) {
      console.error('Erro ao publicar:', error);
      Alert.alert('Erro', 'Não foi possível publicar a notícia');
    } finally {
      setCarregandoSubmit(false);
    }
  };

  // Renderização condicional
  if (!authVerificada) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color="#2c3e50" />
        <Text style={styles.centeredText}>Verificando autenticação...</Text>
      </View>
    );
  }

  if (!usuarioAutenticado) {
    return (
      <View style={[styles.container, styles.centered]}>
        <Text style={styles.authMessage}>Você precisa estar logado para acessar esta página.</Text>
        <TouchableOpacity
          style={styles.loginButton}
          onPress={() => router.push('/views/Login')} // Ajuste o caminho para sua tela de Login
        >
          <Text style={styles.loginButtonText}>Ir para Login</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Se authVerificada é true e usuarioAutenticado é true, renderiza o conteúdo principal
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Nova Publicação</Text>
      
      {tipoUsuario && (
        <View style={[
          styles.badgeTipoUsuario,
          tipoUsuario === 'admin' ? styles.badgeAdmin : styles.badgeJornalista
        ]}>
          <Text style={styles.textoBadge}>
            {tipoUsuario.toUpperCase()}
          </Text>
        </View>
      )}

      <TextInput
        style={styles.input}
        value={titulo}
        onChangeText={setTitulo}
        placeholder="Digite o título da publicação..."
        placeholderTextColor="#999"
        maxLength={100}
      />

      <TextInput
        style={[styles.input, styles.textarea]}
        multiline
        numberOfLines={4}
        value={conteudo}
        onChangeText={setConteudo}
        placeholder="Digite o conteúdo da publicação..."
        placeholderTextColor="#999"
      />

      <TextInput
        style={styles.input}
        value={autorNome}
        onChangeText={setAutorNome}
        placeholder="Seu nome (como autor)"
        placeholderTextColor="#999"
        editable={!auth.currentUser?.displayName || auth.currentUser.displayName !== autorNome}
      />

      <TouchableOpacity 
        style={styles.botaoImagem} 
        onPress={selecionarImagem}
        disabled={carregandoSubmit}
      >
        <Text style={styles.botaoImagemTexto}>
          {imagem ? 'Alterar Imagem' : 'Selecionar Imagem'}
        </Text>
      </TouchableOpacity>

      {imagem && (
        <Image 
          source={{ uri: imagem }} 
          style={styles.imagemPreview} 
          resizeMode="cover"
        />
      )}

      <TouchableOpacity 
        style={[
          styles.botaoPublicar, 
          carregandoSubmit && styles.botaoDesabilitado
        ]} 
        onPress={publicar}
        disabled={carregandoSubmit}
      >
        {carregandoSubmit ? (
            <ActivityIndicator size="small" color="#fff" />
        ) : (
            <Text style={styles.botaoPublicarTexto}>Publicar</Text>
        )}
      </TouchableOpacity>

      <View style={styles.viralContainer}>
        <Text style={styles.viralText}>
          Potencial de Viralidade: {Math.round(pontuacao)} pontos
        </Text>
        <View style={styles.barraFundo}>
          <Animated.View
            style={[
              styles.barra, 
              { 
                width: larguraInterpolada, 
                backgroundColor: barColor 
              }
            ]}
          />
        </View>
        <Text style={styles.dicaViral}>
          Dica: Use palavras-chave relevantes no título e conteúdo para aumentar o alcance
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#F8F8FF',
    flexGrow: 1,
  },
  centered: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1, // Adicionado para garantir que o container centrado ocupe toda a tela
  },
  centeredText: {
    marginTop: 10,
    fontSize: 16,
    color: '#333',
  },
  authMessage: {
    fontSize: 18,
    color: '#2c3e50',
    textAlign: 'center',
    marginBottom: 20,
  },
  loginButton: {
    backgroundColor: '#3498db',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
    elevation: 3,
  },
  loginButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  titulo: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#2c3e50',
  },
  badgeTipoUsuario: {
    alignSelf: 'center',
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 12,
    marginBottom: 15,
  },
  badgeAdmin: {
    backgroundColor: '#d32f2f',
  },
  badgeJornalista: {
    backgroundColor: '#1976d2',
  },
  textoBadge: { // Adicionado estilo para o texto dentro do badge
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  input: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 15,
    fontSize: 16,
    color: '#333',
  },
  textarea: {
    height: 150,
    textAlignVertical: 'top',
  },
  botaoImagem: {
    backgroundColor: '#3498db',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: 'center',
    elevation: 3,
  },
  botaoImagemTexto: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  botaoPublicar: {
    backgroundColor: '#2ecc71',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 3,
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  botaoDesabilitado: {
    backgroundColor: '#95a5a6',
  },
  botaoPublicarTexto: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
    marginLeft: 5,
  },
  imagemPreview: {
    width: '100%',
    height: 200,
    marginBottom: 15,
    borderRadius: 8,
    backgroundColor: '#eee',
  },
  viralContainer: {
    marginTop: 30,
    marginBottom: 20,
  },
  viralText: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 10,
    color: '#2c3e50',
    textAlign: 'center',
  },
  dicaViral: {
    fontSize: 14,
    color: '#7f8c8d',
    marginTop: 10,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  barraFundo: {
    width: '100%',
    height: 20,
    backgroundColor: '#ecf0f1',
    borderRadius: 10,
    overflow: 'hidden',
  },
  barra: {
    height: '100%',
  },
});
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  ScrollView,
  Animated,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { db, storage } from '../services/firebaseConfig';
import { getAuth } from 'firebase/auth';
import * as ImagePicker from 'expo-image-picker';
import { collection, addDoc, serverTimestamp, doc, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import frequenciasJson from '../../assets/palavras-chave.json';

const normalizeString = (str) =>
  str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export default function TelaBarViralidade() {
  const [titulo, setTitulo] = useState('');
  const [conteudo, setConteudo] = useState('');
  const [imagem, setImagem] = useState(null);
  const [autorNome, setAutorNome] = useState('');
  const [freqNormalized, setFreqNormalized] = useState({});
  const [maxPontuacao, setMaxPontuacao] = useState(1);
  const [pontuacao, setPontuacao] = useState(0);
  const [carregando, setCarregando] = useState(false);
  const [tipoUsuario, setTipoUsuario] = useState('');
  const animatedValue = useRef(new Animated.Value(0)).current;

  const auth = getAuth();

  // Carrega dados do usuário incluindo tipo
  useEffect(() => {
    const carregarDadosUsuario = async () => {
      const user = auth.currentUser;
      if (user) {
        if (user.displayName) {
          setAutorNome(user.displayName);
        }
        
        try {
          const userDoc = await getDoc(doc(db, 'usuarios', user.uid));
          if (userDoc.exists()) {
            setTipoUsuario(userDoc.data().tipo || 'jornalista');
          }
        } catch (error) {
          console.error("Erro ao carregar dados do usuário:", error);
          setTipoUsuario('jornalista'); // Padrão para jornalista se erro
        }
      }
    };

    carregarDadosUsuario();
  }, []);

  // Normalização das palavras-chave
  useEffect(() => {
    const normalizedMap = {};
    let total = 0;
    Object.entries(frequenciasJson).forEach(([orig, peso]) => {
      const key = normalizeString(orig);
      normalizedMap[key] = peso;
      total += peso;
    });
    setFreqNormalized(normalizedMap);
    setMaxPontuacao(total);
  }, []);

  // Cálculo da pontuação de viralidade
  useEffect(() => {
    const normalizeAndSplit = (text) =>
      text
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .split(/\W+/)
        .filter((w) => w.length > 0);

    const titleWords = normalizeAndSplit(titulo);
    const contentWords = normalizeAndSplit(conteudo);

    let soma = 0;
    titleWords.forEach((palavra) => {
      if (freqNormalized[palavra] !== undefined) {
        soma += freqNormalized[palavra] * 2;
      }
    });
    contentWords.forEach((palavra) => {
      if (freqNormalized[palavra] !== undefined) {
        soma += freqNormalized[palavra];
      }
    });

    setPontuacao(soma);
  }, [titulo, conteudo, freqNormalized]);

  // Animação da barra de viralidade
  useEffect(() => {
    if (maxPontuacao <= 0) return;
    const basePercent = (pontuacao / maxPontuacao) * 100;
    const sensibilidade = 2.5;
    const novoPercent = Math.min(basePercent / sensibilidade, 100);

    Animated.timing(animatedValue, {
      toValue: novoPercent,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [pontuacao, maxPontuacao, animatedValue]);

  const larguraInterpolada = animatedValue.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  const barColor = animatedValue.interpolate({
    inputRange: [0, 30, 70, 100],
    outputRange: ['#e53935', '#e53935', '#f57c00', '#43a047'],
  });

  // Selecionar imagem da galeria
  const selecionarImagem = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets.length > 0) {
        setImagem(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Erro ao selecionar imagem:', error);
      Alert.alert('Erro', 'Não foi possível selecionar a imagem');
    }
  };

  // Função para publicar a notícia
  const publicar = async () => {
    if (!titulo.trim() || !conteudo.trim()) {
      Alert.alert('Erro', 'Título e conteúdo são obrigatórios!');
      return;
    }

    const user = auth.currentUser;
    if (!user) {
      Alert.alert('Erro', 'Você precisa estar logado para publicar!');
      return;
    }

    setCarregando(true);

    try {
      let imagemUrl = '';
      
      if (imagem) {
        const response = await fetch(imagem);
        const blob = await response.blob();
        const filename = `noticias/${user.uid}/${Date.now()}.jpg`;
        const storageRef = ref(storage, filename);
        await uploadBytes(storageRef, blob);
        imagemUrl = await getDownloadURL(storageRef);
      }

      // Adiciona documento no Firestore
      await addDoc(collection(db, 'noticias'), {
        titulo: titulo.trim(),
        conteudo: conteudo.trim(),
        imagem: imagemUrl,
        pontuacao,
        criadoEm: serverTimestamp(),
        atualizadoEm: serverTimestamp(),
        visualizacoes: 0,
        curtidas: 0,
        autorId: user.uid,
        autorEmail: user.email,
        autorNome: autorNome.trim() || user.displayName || 'Anônimo',
        autorTipo: tipoUsuario || 'jornalista',
        status: 'publicado',
        // Campos adicionais para administradores
        ...(tipoUsuario === 'admin' && { 
          oficial: true,
          prioridade: 1 
        })
      });

      Alert.alert('Sucesso', 'Notícia publicada com sucesso!');
      
      // Resetar formulário
      setTitulo('');
      setConteudo('');
      setImagem(null);
      setPontuacao(0);
    } catch (error) {
      console.error('Erro ao publicar:', error);
      Alert.alert('Erro', 'Não foi possível publicar a notícia');
    } finally {
      setCarregando(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>Nova Publicação</Text>
      
      {tipoUsuario && (
        <View style={[
          styles.badgeTipoUsuario,
          tipoUsuario === 'admin' ? styles.badgeAdmin : styles.badgeJornalista
        ]}>
          <Text style={styles.textoBadge}>
            {tipoUsuario === 'admin' ? 'ADMIN' : 'JORNALISTA'}
          </Text>
        </View>
      )}

      <TextInput
        style={styles.input}
        value={titulo}
        onChangeText={setTitulo}
        placeholder="Digite o título da publicação..."
        placeholderTextColor="#999"
        maxLength={100}
      />

      <TextInput
        style={[styles.input, styles.textarea]}
        multiline
        numberOfLines={4}
        value={conteudo}
        onChangeText={setConteudo}
        placeholder="Digite o conteúdo da publicação..."
        placeholderTextColor="#999"
      />

      <TextInput
        style={styles.input}
        value={autorNome}
        onChangeText={setAutorNome}
        placeholder="Seu nome (como autor)"
        placeholderTextColor="#999"
        editable={!auth.currentUser?.displayName}
      />

      <TouchableOpacity 
        style={styles.botaoImagem} 
        onPress={selecionarImagem}
        disabled={carregando}
      >
        <Text style={styles.botaoImagemTexto}>
          {imagem ? 'Alterar Imagem' : 'Selecionar Imagem'}
        </Text>
      </TouchableOpacity>

      {imagem && (
        <Image 
          source={{ uri: imagem }} 
          style={styles.imagemPreview} 
          resizeMode="cover"
        />
      )}

      <TouchableOpacity 
        style={[
          styles.botaoPublicar, 
          carregando && styles.botaoDesabilitado
        ]} 
        onPress={publicar}
        disabled={carregando}
      >
        <Text style={styles.botaoPublicarTexto}>
          {carregando ? 'Publicando...' : 'Publicar'}
        </Text>
      </TouchableOpacity>

      <View style={styles.viralContainer}>
        <Text style={styles.viralText}>
          Potencial de Viralidade: {Math.round(pontuacao)} pontos
        </Text>
        <View style={styles.barraFundo}>
          <Animated.View
            style={[
              styles.barra, 
              { 
                width: larguraInterpolada, 
                backgroundColor: barColor 
              }
            ]}
          />
        </View>
        <Text style={styles.dicaViral}>
          Dica: Use palavras-chave relevantes no título e conteúdo para aumentar o alcance
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#F8F8FF',
    flexGrow: 1,
  },
  titulo: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#2c3e50',
  },
  badgeTipoUsuario: {
    alignSelf: 'center',
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 12,
    marginBottom: 15,
  },
  badgeAdmin: {
    backgroundColor: '#d32f2f',
  },
  badgeJornalista: {
    backgroundColor: '#1976d2',
  },
  textoBadge: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
  },
  input: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 15,
    fontSize: 16,
    color: '#333',
  },
  textarea: {
    height: 150,
    textAlignVertical: 'top',
  },
  botaoImagem: {
    backgroundColor: '#3498db',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: 'center',
    elevation: 3,
  },
  botaoImagemTexto: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  botaoPublicar: {
    backgroundColor: '#2ecc71',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    elevation: 3,
    marginTop: 10,
  },
  botaoDesabilitado: {
    backgroundColor: '#95a5a6',
  },
  botaoPublicarTexto: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  imagemPreview: {
    width: '100%',
    height: 200,
    marginBottom: 15,
    borderRadius: 8,
    backgroundColor: '#eee',
  },
  viralContainer: {
    marginTop: 30,
    marginBottom: 20,
  },
  viralText: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 10,
    color: '#2c3e50',
    textAlign: 'center',
  },
  dicaViral: {
    fontSize: 14,
    color: '#7f8c8d',
    marginTop: 10,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  barraFundo: {
    width: '100%',
    height: 20,
    backgroundColor: '#ecf0f1',
    borderRadius: 10,
    overflow: 'hidden',
  },
  barra: {
    height: '100%',
  },
});
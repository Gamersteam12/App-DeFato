import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, Button, StyleSheet, Alert } from 'react-native';
import { collection, getDocs, updateDoc, doc } from 'firebase/firestore';
import { db } from '../services/firebaseConfig';

export default function TelaValidarUsuarios() {
  const [usuariosPendentes, setUsuariosPendentes] = useState([]);

  const carregarPendentes = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'usuario')); // ajuste no nome da coleção
      const lista = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();

        // se status não for "aprovado", considera pendente
        if (data.status !== 'aprovado') {
          lista.push({ id: docSnap.id, ...data });
        }
      });
      setUsuariosPendentes(lista);
    } catch (e) {
      Alert.alert('Erro', 'Não foi possível carregar usuários.');
    }
  };

  const validarUsuario = async (id, novoTipo) => {
    try {
      await updateDoc(doc(db, 'usuario', id), {
        status: 'aprovado', // atualiza o status para "aprovado"
        tipo: novoTipo,
      });
      Alert.alert('Sucesso', `Usuário validado como ${novoTipo}`);
      carregarPendentes();
    } catch (e) {
      Alert.alert('Erro', 'Não foi possível validar o usuário.');
    }
  };

  useEffect(() => {
    carregarPendentes();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Usuários Pendentes</Text>
      {usuariosPendentes.length === 0 ? (
        <Text style={styles.nenhum}>Nenhum usuário pendente</Text>
      ) : (
        <FlatList
          data={usuariosPendentes}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text>{item.email}</Text>
              <View style={styles.botoes}>
                <Button
                  title="Jornalista"
                  onPress={() => validarUsuario(item.id, 'jornalista')}
                />
                <Button
                  title="Administrador"
                  color="#d33"
                  onPress={() => validarUsuario(item.id, 'administrador')}
                />
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  titulo: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
  card: {
    backgroundColor: '#f1f1f1',
    padding: 15,
    marginBottom: 10,
    borderRadius: 8,
  },
  botoes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  nenhum: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#888',
  },
});

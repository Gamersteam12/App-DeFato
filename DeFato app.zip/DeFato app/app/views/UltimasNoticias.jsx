import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
  FlatList,
} from 'react-native';
import { collection, query, orderBy, limit, getDocs, doc, getDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { db } from '../services/firebaseConfig';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useRouter } from 'expo-router';

export default function TelaUltimasNoticias() {
  const router = useRouter();
  const [noticias, setNoticias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [usuarioAdmin, setUsuarioAdmin] = useState(false);

  const carregarNoticias = async () => {
    try {
      setError('');
      const q = query(
        collection(db, 'noticias'),
        orderBy('criadoEm', 'desc'),
        limit(20)
      );

      const querySnapshot = await getDocs(q);
      const noticiasData = [];

      querySnapshot.forEach((doc) => {
        const dados = doc.data();
        noticiasData.push({
          id: doc.id,
          titulo: dados.titulo || 'Sem título',
          conteudo: dados.conteudo || '',
          imagemUrl: dados.imagem || null,
          criadoEm: dados.criadoEm?.toDate() || new Date(),
          atualizadoEm: dados.atualizadoEm?.toDate() || null,
          autorNome: dados.autorNome || 'Anônimo',
          autorTipo: dados.autorTipo || 'jornalista',
          visualizacoes: dados.visualizacoes || 0,
          curtidas: dados.curtidas || 0,
          pontuacao: dados.pontuacao || 0,
          status: dados.status || 'rascunho'
        });
      });

      setNoticias(noticiasData);
    } catch (err) {
      console.error('Erro ao carregar notícias:', err);
      setError('Erro ao carregar notícias. Tente novamente.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const verificarPermissaoUsuario = async () => {
    const usuarioAtual = getAuth().currentUser;
    if (!usuarioAtual) return;

    try {
      const docRef = doc(db, 'usuarios', usuarioAtual.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const dados = docSnap.data();
        setUsuarioAdmin(dados.tipo === 'admin' && dados.status === 'aprovado');
      }
    } catch (error) {
      console.error('Erro ao verificar permissão:', error);
    }
  };

  useEffect(() => {
    carregarNoticias();
    verificarPermissaoUsuario();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    carregarNoticias();
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.noticiaContainer}
      onPress={() => router.push({ 
        pathname: '/views/TelaNoticiaDetalhe', 
        params: { noticiaId: item.id }
      })}
    >
      {item.imagemUrl && (
        <Image 
          source={{ uri: item.imagemUrl }} 
          style={styles.noticiaImagem} 
          resizeMode="cover"
        />
      )}
      
      <View style={styles.noticiaConteudo}>
        <View style={styles.cabecalhoNoticia}>
          {item.autorTipo === 'admin' && (
            <View style={styles.badgeOficial}>
              <Text style={styles.badgeOficialTexto}>OFICIAL</Text>
            </View>
          )}
          <Text style={styles.autorTexto}>
            Por {item.autorNome} • {formatDistanceToNow(item.criadoEm, {
              addSuffix: true,
              locale: ptBR
            })}
          </Text>
        </View>
        
        <Text style={styles.noticiaTitulo} numberOfLines={2}>
          {item.titulo}
        </Text>
        
        <Text style={styles.noticiaResumo} numberOfLines={3}>
          {item.conteudo}
        </Text>
        
        <View style={styles.rodapeNoticia}>
          <View style={styles.metricasContainer}>
            <View style={styles.metricaItem}>
              <Icon name="remove-red-eye" size={16} color="#666" />
              <Text style={styles.metricaTexto}>{item.visualizacoes}</Text>
            </View>
            <View style={styles.metricaItem}>
              <Icon name="thumb-up" size={16} color="#666" />
              <Text style={styles.metricaTexto}>{item.curtidas}</Text>
            </View>
            {item.pontuacao > 0 && (
              <View style={styles.metricaItem}>
                <Icon name="trending-up" size={16} color="#666" />
                <Text style={styles.metricaTexto}>{item.pontuacao}</Text>
              </View>
            )}
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#B00000" />
        <Text style={styles.loadingText}>Carregando notícias...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={noticias}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listaContainer}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#B00000']}
            tintColor="#B00000"
          />
        }
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="info-outline" size={50} color="#999" />
            <Text style={styles.emptyText}>
              {error || 'Nenhuma notícia encontrada.'}
            </Text>
          </View>
        }
      />

      {usuarioAdmin && (
        <TouchableOpacity
          style={styles.botaoNovaNoticia}
          onPress={() => router.push('/views/TelaPublicarNoticia')}
        >
          <Icon name="add" size={30} color="#fff" />
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F8FF',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#B00000',
  },
  listaContainer: {
    padding: 15,
  },
  noticiaContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 20,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  noticiaImagem: {
    width: '100%',
    height: 200,
  },
  noticiaConteudo: {
    padding: 16,
  },
  cabecalhoNoticia: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  badgeOficial: {
    backgroundColor: '#B00000',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginRight: 8,
  },
  badgeOficialTexto: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  autorTexto: {
    fontSize: 12,
    color: '#666',
  },
  noticiaTitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 8,
    lineHeight: 24,
  },
  noticiaResumo: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
    lineHeight: 20,
  },
  rodapeNoticia: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metricasContainer: {
    flexDirection: 'row',
  },
  metricaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  metricaTexto: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    marginTop: 10,
    textAlign: 'center',
  },
  botaoNovaNoticia: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    backgroundColor: '#B00000',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
  },
});
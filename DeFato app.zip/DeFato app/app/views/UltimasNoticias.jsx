import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  RefreshControl,
  FlatList,
} from 'react-native';
import { collection, query, orderBy, limit, getDocs, doc, getDoc } from 'firebase/firestore';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { db } from '../services/firebaseConfig'; // Certifique-se que este caminho está correto
import Icon from 'react-native-vector-icons/MaterialIcons';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useRouter } from 'expo-router';

export default function TelaUltimasNoticias() {
  const router = useRouter();
  const [noticias, setNoticias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [usuarioAdmin, setUsuarioAdmin] = useState(false);
  // Removido o estado currentUser pois onAuthStateChanged já passa o usuário diretamente
  // e getAuth().currentUser pode ser usado no onRefresh se necessário.

  // Função para carregar notícias
  const carregarNoticias = async () => {
    try {
      setError('');
      setLoading(true);
      const q = query(
        collection(db, 'noticias'),
        orderBy('criadoEm', 'desc'),
        limit(20)
      );

      const querySnapshot = await getDocs(q);
      const noticiasData = [];

      querySnapshot.forEach((doc) => {
        const dados = doc.data();
        noticiasData.push({
          id: doc.id,
          titulo: dados.titulo || 'Sem título',
          conteudo: dados.conteudo || '',
          imagemUrl: dados.imagemUrl || dados.imagem || null, // Adicionado dados.imagemUrl para consistência
          criadoEm: dados.criadoEm?.toDate() || new Date(),
          atualizadoEm: dados.atualizadoEm?.toDate() || null,
          autorNome: dados.autorNome || 'Anônimo',
          autorTipo: dados.autorTipo || 'jornalista',
          visualizacoes: dados.visualizacoes || 0,
          curtidas: dados.curtidas || 0,
          pontuacao: dados.pontuacao || 0,
          status: dados.status || 'rascunho'
        });
      });

      setNoticias(noticiasData);
    } catch (err) {
      console.error('Erro ao carregar notícias:', err);
      setError('Erro ao carregar notícias. Tente novamente.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Função para verificar permissão do usuário
  const verificarPermissaoUsuario = async (user) => {
    if (!user) {
      setUsuarioAdmin(false);
      return;
    }

    try {
      // 👇 ALTERAÇÃO PRINCIPAL AQUI 👇
      const docRef = doc(db, 'usuario', user.uid); // Alterado de "usuarios" para "usuario"
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const dados = docSnap.data();
        // Certifique-se que os campos 'tipo' e 'status' existem no seu documento de usuário
        // e correspondem à lógica de como um admin é definido.
        setUsuarioAdmin(dados.tipo === 'admin' && dados.status === 'aprovado');
      } else {
        console.log("Documento do usuário não encontrado na coleção 'usuario'.");
        setUsuarioAdmin(false);
      }
    } catch (error) {
      console.error('Erro ao verificar permissão:', error);
      setUsuarioAdmin(false); // Assume não admin em caso de erro
    }
  };

  useEffect(() => {
    carregarNoticias();

    const auth = getAuth();
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        verificarPermissaoUsuario(user);
      } else {
        setUsuarioAdmin(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    carregarNoticias();
    const auth = getAuth();
    if (auth.currentUser) {
      verificarPermissaoUsuario(auth.currentUser);
    } else {
      setUsuarioAdmin(false); // Garante que se o usuário deslogar, o status de admin é resetado.
    }
  };

  function renderItem({ item }) { // Movido para dentro do escopo do componente ou certifique-se que está acessível
    return (
      <TouchableOpacity
        style={styles.noticiaContainer}
        onPress={() => router.push({
          pathname: '/views/TelaNoticiaDetalhe', // Verifique se este caminho está correto
          params: { noticiaId: item.id }
        })}
      >
        {item.imagemUrl && (
          <Image
            source={{ uri: item.imagemUrl }}
            style={styles.noticiaImagem}
            resizeMode="cover"
          />
        )}

        <View style={styles.noticiaConteudo}>
          <View style={styles.cabecalhoNoticia}>
            {item.autorTipo === 'admin' && (
              <View style={styles.badgeOficial}>
                <Text style={styles.badgeOficialTexto}>OFICIAL</Text>
              </View>
            )}
            <Text style={styles.autorTexto}>
              Por {item.autorNome} • {formatDistanceToNow(item.criadoEm, {
                addSuffix: true,
                locale: ptBR
              })}
            </Text>
          </View>

          <Text style={styles.noticiaTitulo} numberOfLines={2}>
            {item.titulo}
          </Text>

          <Text style={styles.noticiaResumo} numberOfLines={3}>
            {item.conteudo}
          </Text>

          <View style={styles.rodapeNoticia}>
            <View style={styles.metricasContainer}>
              <View style={styles.metricaItem}>
                <Icon name="remove-red-eye" size={16} color="#666" />
                <Text style={styles.metricaTexto}>{item.visualizacoes}</Text>
              </View>
              <View style={styles.metricaItem}>
                <Icon name="thumb-up" size={16} color="#666" />
                <Text style={styles.metricaTexto}>{item.curtidas}</Text>
              </View>
              {item.pontuacao > 0 && (
                <View style={styles.metricaItem}>
                  <Icon name="trending-up" size={16} color="#666" />
                  <Text style={styles.metricaTexto}>{item.pontuacao}</Text>
                </View>
              )}
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  if (loading && noticias.length === 0) { // Mostra o loading inicial apenas se não houver notícias ainda
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#B00000" />
        <Text style={styles.loadingText}>Carregando notícias...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={noticias}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listaContainer}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#B00000']}
            tintColor="#B00000"
          />
        }
        ListEmptyComponent={
          !loading ? ( // Só mostra a mensagem de vazio se não estiver carregando
            <View style={styles.emptyContainer}>
              <Icon name="info-outline" size={50} color="#999" />
              <Text style={styles.emptyText}>
                {error || 'Nenhuma notícia encontrada.'}
              </Text>
            </View>
          ) : null
        }
      />

      {usuarioAdmin && (
        <TouchableOpacity
          style={styles.botaoNovaNoticia}
          onPress={() => router.push('/views/TelaPublicarNoticia')} // Verifique se este caminho está correto
        >
          <Icon name="add" size={30} color="#fff" />
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F8FF',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#B00000',
  },
  listaContainer: {
    padding: 15,
    paddingBottom: 80, // Espaço para o botão FAB não sobrepor o último item
  },
  noticiaContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 20,
    overflow: 'hidden',
    elevation: 3, // Aumentei um pouco a elevação para destaque
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15, // Ajustei opacidade
    shadowRadius: 5,    // Ajustei raio
  },
  noticiaImagem: {
    width: '100%',
    height: 200,
  },
  noticiaConteudo: {
    padding: 16,
  },
  cabecalhoNoticia: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  badgeOficial: {
    backgroundColor: '#B00000',
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginRight: 8,
  },
  badgeOficialTexto: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  autorTexto: {
    fontSize: 12,
    color: '#666',
  },
  noticiaTitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 8,
    lineHeight: 24,
  },
  noticiaResumo: {
    fontSize: 14,
    color: '#555', // Um pouco mais escuro para melhor leitura
    marginBottom: 12,
    lineHeight: 20,
  },
  rodapeNoticia: {
    flexDirection: 'row',
    justifyContent: 'space-between', // Alterado para space-between se houver outros elementos à direita
    alignItems: 'center',
    marginTop: 8, // Adicionado um pouco de margem superior
  },
  metricasContainer: {
    flexDirection: 'row',
    alignItems: 'center', // Alinhamento vertical das métricas
  },
  metricaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  metricaTexto: {
    fontSize: 12,
    color: '#666',
    marginLeft: 4,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    marginTop: 50,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    marginTop: 10,
    textAlign: 'center',
  },
  botaoNovaNoticia: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    backgroundColor: '#B00000',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
  },
});
import React from 'react';
import { View, Text, ScrollView, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';

export default function ManchetesScreen() {
  const router = useRouter();

  // Dados de exemplo para as manchetes
  const manchetes = [
    {
      id: 1,
      titulo: 'Economia brasileira cresce 1,2% no primeiro trimestre',
      resumo: 'Dados do IBGE mostram recuperação em setores-chave após período de retração',
      imagem: 'https://via.placeholder.com/300x200?text=Economia',
      data: '15/05/2023'
    },
    {
      id: 2,
      titulo: 'Novo tratamento para diabetes mostra eficácia em testes',
      resumo: 'Pesquisa brasileira avança na busca por cura da doença que afeta milhões',
      imagem: 'https://via.placeholder.com/300x200?text=Saúde',
      data: '14/05/2023'
    },
    {
      id: 3,
      titulo: 'Conferência climática discute metas mais ambiciosas',
      resumo: 'Líderes mundiais se reúnem para estabelecer novos compromissos ambientais',
      imagem: 'https://via.placeholder.com/300x200?text=Meio+Ambiente',
      data: '13/05/2023'
    },
    {
      id: 4,
      titulo: 'Tecnologia 5G chega a mais 15 cidades brasileiras',
      resumo: 'Expansão da rede promete revolucionar conectividade no país',
      imagem: 'https://via.placeholder.com/300x200?text=Tecnologia',
      data: '12/05/2023'
    },
  ];

  const abrirNoticia = (id) => {
    router.push(`../views/TelaNoticiaDetalhe?id=${id}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>MANCHETES</Text>
      
      <ScrollView>
        {manchetes.map((noticia) => (
          <TouchableOpacity 
            key={noticia.id} 
            style={styles.card}
            onPress={() => abrirNoticia(noticia.id)}
          >
            <Image 
              source={{ uri: noticia.imagem }} 
              style={styles.imagem} 
            />
            <View style={styles.conteudo}>
              <Text style={styles.data}>{noticia.data}</Text>
              <Text style={styles.tituloNoticia}>{noticia.titulo}</Text>
              <Text style={styles.resumo}>{noticia.resumo}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 16,
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#C8102E',
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    marginBottom: 20,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  imagem: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  conteudo: {
    padding: 16,
  },
  data: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
  },
  tituloNoticia: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333',
  },
  resumo: {
    fontSize: 14,
    color: '#555',
    lineHeight: 20,
  },
});
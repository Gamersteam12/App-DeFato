import React, { useEffect, useState } from 'react';
import { View, TextInput, Text, TouchableOpacity, Alert, ActivityIndicator, ScrollView } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { doc, getDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db, auth } from '../services/firebaseConfig';

export default function TelaEdicaoNoticia() {
  const { noticiaId } = useLocalSearchParams();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  const [titulo, setTitulo] = useState('');
  const [conteudo, setConteudo] = useState('');
  const [imagen, setImagen] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [usuarioPodeEditar, setUsuarioPodeEditar] = useState(false);

  useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  useEffect(() => {
    const carregarNoticia = async () => {
      try {
        const user = auth.currentUser;
        if (!user) {
          if (mounted) {
            Alert.alert('Erro', 'Usuário não autenticado');
            router.back();
          }
          return;
        }

        const docRef = doc(db, 'noticias', noticiaId);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const dados = docSnap.data();
          setTitulo(dados.titulo || '');
          setConteudo(dados.conteudo || '');
          setImagen(dados.imagen || '');

          // Permitir edição se for o autor
          if (user.uid === dados.autorId) {
            setUsuarioPodeEditar(true);
          } else {
            // Verificar se o usuário é admin para também permitir exclusão
            const adminRef = doc(db, 'admins', user.uid);
            const adminSnap = await getDoc(adminRef);
            if (adminSnap.exists() && adminSnap.data().isAdmin === true) {
              setUsuarioPodeEditar(true);
            }
          }
        } else {
          if (mounted) {
            Alert.alert('Erro', 'Notícia não encontrada.');
            router.back();
          }
        }
      } catch (error) {
        console.error('Erro ao carregar notícia:', error);
        if (mounted) {
          Alert.alert('Erro', 'Não foi possível carregar a notícia.');
          router.back();
        }
      } finally {
        setCarregando(false);
      }
    };

    carregarNoticia();
  }, [noticiaId, mounted]);

  const navegarComSeguranca = (acao) => {
    if (mounted) {
      acao();
    }
  };

  const salvarNoticia = async () => {
    if (!titulo.trim() || !conteudo.trim()) {
      Alert.alert('Atenção', 'Título e conteúdo não podem estar vazios.');
      return;
    }

    try {
      const user = auth.currentUser;
      if (!user) {
        Alert.alert('Erro', 'Usuário não autenticado');
        return;
      }

      const docRef = doc(db, 'noticias', noticiaId);
      await updateDoc(docRef, {
        titulo: titulo,
        conteudo: conteudo,
        imagen: imagen,
        atualizadoEm: new Date(),
        autorId: user.uid,
        autorEmail: user.email
      });

      Alert.alert('Sucesso', 'Notícia atualizada com sucesso!');
      navegarComSeguranca(() => router.back());
    } catch (error) {
      console.error('Erro ao atualizar notícia:', error);
      Alert.alert('Erro', `Não foi possível salvar as alterações: ${error.message}`);
    }
  };

  const excluirNoticia = async () => {
    const user = auth.currentUser;
    if (!user) {
      Alert.alert('Erro', 'Usuário não autenticado');
      return;
    }

    Alert.alert(
      'Confirmar Exclusão',
      'Tem certeza que deseja excluir esta notícia permanentemente?',
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: async () => {
            try {
              const docRef = doc(db, 'noticias', noticiaId);
              await deleteDoc(docRef);
              Alert.alert('Sucesso', 'Notícia excluída com sucesso!');
              navegarComSeguranca(() => router.replace('/'));
            } catch (error) {
              console.error('Erro ao excluir notícia:', error);
              Alert.alert('Erro', `Não foi possível excluir: ${error.message}`);
            }
          }
        }
      ]
    );
  };

  if (carregando) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#4285F4" />
        <Text>Carregando notícia...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>Editar Notícia</Text>

      <TextInput
        placeholder="Título"
        value={titulo}
        onChangeText={setTitulo}
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          borderRadius: 8,
          padding: 10,
          marginBottom: 10
        }}
      />

      <TextInput
        placeholder="Conteúdo"
        value={conteudo}
        onChangeText={setConteudo}
        multiline
        numberOfLines={10}
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          borderRadius: 8,
          padding: 10,
          textAlignVertical: 'top',
          marginBottom: 10,
          minHeight: 200
        }}
      />

      <TextInput
        placeholder="URL da Imagem"
        value={imagen}
        onChangeText={setImagen}
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          borderRadius: 8,
          padding: 10,
          marginBottom: 20
        }}
      />

      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <TouchableOpacity
          onPress={salvarNoticia}
          style={{
            backgroundColor: '#4CAF50',
            padding: 15,
            borderRadius: 8,
            alignItems: 'center',
            flex: 1,
            marginRight: 10
          }}
        >
          <Text style={{ color: 'white', fontWeight: 'bold' }}>Salvar</Text>
        </TouchableOpacity>

        {usuarioPodeEditar && (
          <TouchableOpacity
            onPress={excluirNoticia}
            style={{
              backgroundColor: '#f44336',
              padding: 15,
              borderRadius: 8,
              alignItems: 'center',
              flex: 1,
              marginLeft: 10
            }}
          >
            <Text style={{ color: 'white', fontWeight: 'bold' }}>Excluir</Text>
          </TouchableOpacity>
        )}
      </View>
    </ScrollView>
  );
}

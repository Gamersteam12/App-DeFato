import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Pressable, 
  ScrollView, 
  TouchableOpacity, 
  Image,
  ActivityIndicator,
  RefreshControl,
  Alert
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { auth, db } from './services/firebaseConfig';  // com ponto no início
import { collection, query, orderBy, limit, where, getDocs } from 'firebase/firestore';

// Constantes para as abas
const TABS = {
  HEADLINES: 'MANCHETES',
  LATEST: 'ÚLTIMAS',
  AI_VERIFIER: 'VERIFICADOR IA'
};

// Valores padrão para notícia
const DEFAULT_NEWS = {
  titulo: 'Sem título',
  conteudo: '',
  autorNome: 'Redação',
  visualizacoes: 0,
  pontuacao: 0,
  imagem: null
};

// Função para formatar a data de forma relativa (substitui o date-fns)
const formatRelativeTime = (date) => {
  if (!(date instanceof Date)) {
    date = date.toDate(); // Converte Timestamp do Firebase para Date se necessário
  }

  const now = new Date();
  const seconds = Math.floor((now - date) / 1000);
  
  const intervals = {
    ano: 31536000,
    mês: 2592000,
    semana: 604800,
    dia: 86400,
    hora: 3600,
    minuto: 60,
    segundo: 1
  };
  
  for (const [unit, secondsInUnit] of Object.entries(intervals)) {
    const interval = Math.floor(seconds / secondsInUnit);
    if (interval >= 1) {
      return `há ${interval} ${unit}${interval === 1 ? '' : 's'}`;
    }
  }
  
  return 'agora mesmo';
};

export default function NoticiasScreen() {
  const [activeTab, setActiveTab] = useState(TABS.HEADLINES);
  const [noticias, setNoticias] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const navigation = useNavigation();

  const fetchNoticias = async () => {
    try {
      let q;
      
      // Configura queries diferentes para cada aba
      switch(activeTab) {
        case TABS.HEADLINES:
          q = query(
            collection(db, 'noticias'),
            where('status', '==', 'publicado'),
            where('pontuacao', '>=', 300),
            orderBy('pontuacao', 'desc'),
            limit(10)
          );
          break;
          
        case TABS.LATEST:
          q = query(
            collection(db, 'noticias'),
            where('status', '==', 'publicado'),
            orderBy('criadoEm', 'desc'),
            limit(20)
          );
          break;
          
        case TABS.AI_VERIFIER:
          q = query(
            collection(db, 'noticias'),
            where('status', '==', 'pendente'),
            orderBy('criadoEm', 'desc'),
            limit(20)
          );
          break;
          
        default:
          q = query(
            collection(db, 'noticias'),
            orderBy('criadoEm', 'desc'),
            limit(20)
          );
      }
      
      const querySnapshot = await getDocs(q);
      const noticiasData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...DEFAULT_NEWS,
        ...doc.data(),
        criadoEm: doc.data().criadoEm || new Date()
      }));
      
      setNoticias(noticiasData);
    } catch (error) {
      console.error("Erro ao buscar notícias:", error);
      Alert.alert('Erro', 'Não foi possível carregar as notícias');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchNoticias();
  }, [activeTab]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchNoticias();
  };

  const handleNoticiaPress = (noticia) => {
    const route = activeTab === TABS.AI_VERIFIER 
      ? 'ValidadorDeNoticia' 
      : 'NoticiaDetalhe';
      
    navigation.navigate(route, { noticiaId: noticia.id });
  };

  const renderNoticiaCard = (noticia) => (
    <TouchableOpacity 
      key={noticia.id}
      style={styles.card}
      onPress={() => handleNoticiaPress(noticia)}
    >
      {noticia.imagemUrl ? (
        <Image 
          source={{ uri: noticia.imagemUrl }}
          style={styles.noticiaImagem}
          resizeMode="cover"
        />
      ) : (
        <View style={styles.imagemPlaceholder}>
          <Text style={styles.placeholderText}>DeFato</Text>
        </View>
      )}
      
      <View style={styles.cardContent}>
        <Text style={styles.titulo} numberOfLines={2}>{noticia.titulo}</Text>
        <View style={styles.noticiaInfo}>
          <Text style={styles.autor}>{noticia.autorNome}</Text>
          <Text style={styles.tempo}>
            {formatRelativeTime(noticia.criadoEm)}
          </Text>
        </View>
        <View style={styles.metricas}>
          <Text style={styles.metrica}>
            👁️ {noticia.visualizacoes} visualizações
          </Text>
          {noticia.pontuacao > 0 && (
            <Text style={styles.metrica}>
              📈 Viralidade: {noticia.pontuacao}
            </Text>
          )}
          {activeTab === TABS.AI_VERIFIER && (
            <Text style={[styles.metrica, styles.pendente]}>
              ⚠️ Pendente
            </Text>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#B00000" />
        <Text style={styles.loadingText}>Carregando notícias...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.tabsContainer}>
        {Object.values(TABS).map((tab) => (
          <Pressable 
            key={tab}
            style={[styles.tab, activeTab === tab && styles.tabAtiva]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextAtiva]}>
              {tab}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.listaNoticias,
          noticias.length === 0 && styles.emptyList
        ]}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#B00000']}
            tintColor="#B00000"
          />
        }
      >
        {noticias.length > 0 ? (
          noticias.map(renderNoticiaCard)
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              {activeTab === TABS.AI_VERIFIER 
                ? 'Nenhuma notícia para verificar' 
                : 'Nenhuma notícia encontrada'}
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

// Estilos permanecem os mesmos
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#B00000',
    fontSize: 16,
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    backgroundColor: '#f9f9f9',
  },
  tab: {
    flex: 1,
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabAtiva: {
    borderBottomWidth: 2,
    borderBottomColor: '#B00000',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#555',
  },
  tabTextAtiva: {
    color: '#B00000',
    fontWeight: 'bold',
  },
  listaNoticias: {
    padding: 16,
  },
  emptyList: {
    flex: 1,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    marginBottom: 16,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  noticiaImagem: {
    width: 100,
    height: 100,
    backgroundColor: '#f0f0f0',
  },
  imagemPlaceholder: {
    width: 100,
    height: 100,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    color: '#999',
    fontWeight: 'bold',
    fontSize: 16,
  },
  cardContent: {
    flex: 1,
    padding: 12,
    justifyContent: 'space-between',
  },
  titulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
    lineHeight: 20,
  },
  noticiaInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  autor: {
    fontSize: 12,
    color: '#B00000',
    fontWeight: '600',
  },
  tempo: {
    fontSize: 12,
    color: '#777',
  },
  metricas: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  metrica: {
    fontSize: 12,
    color: '#555',
    marginRight: 8,
  },
  pendente: {
    color: '#FFA500',
    fontWeight: 'bold',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
  },
});
import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import moment from 'moment';
import 'moment/locale/pt-br';

moment.locale('pt-br');

export default function TelaNoticiaDetalhe({ route }) {
  const { noticia } = route.params;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.titulo}>{noticia.titulo}</Text>
      <Text style={styles.data}>
        {moment(noticia.criadoEm.toDate()).format('LLLL')}
      </Text>
      <Text style={styles.autor}>Publicado por: {noticia.autorEmail}</Text>
      <Text style={styles.conteudo}>{noticia.conteudo}</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#FFF',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#222',
  },
  data: {
    fontSize: 12,
    color: '#777',
    marginBottom: 5,
  },
  autor: {
    fontSize: 13,
    color: '#999',
    marginBottom: 15,
  },
  conteudo: {
    fontSize: 16,
    color: '#333',
    lineHeight: 24,
  },
});

import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { addDoc, collection, Timestamp } from 'firebase/firestore';
import { auth, db, storage } from '../services/firebaseConfig';
import * as ImagePicker from 'expo-image-picker';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { v4 as uuidv4 } from 'uuid';

export default function TelaPublicar() {
  const [titulo, setTitulo] = useState('');
  const [conteudo, setConteudo] = useState('');
  const [imagem, setImagem] = useState(null);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState('');

  const escolherImagem = async () => {
    const resultado = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
    });

    if (!resultado.canceled) {
      setImagem(resultado.assets[0].uri);
    }
  };

  const uploadImagem = async (uri) => {
    const response = await fetch(uri);
    const blob = await response.blob();
    const nomeUnico = `noticias/${uuidv4()}`;
    const imagemRef = ref(storage, nomeUnico);
    await uploadBytes(imagemRef, blob);
    return await getDownloadURL(imagemRef);
  };

  const handlePublicar = async () => {
    setErro('');

    if (!titulo || !conteudo) {
      setErro('Preencha todos os campos.');
      return;
    }

    setLoading(true);
    try {
      const user = auth.currentUser;
      if (!user) {
        setErro('Usuário não autenticado.');
        setLoading(false);
        return;
      }

      let imagemURL = null;
      if (imagem) {
        imagemURL = await uploadImagem(imagem);
      }

      await addDoc(collection(db, 'publicacoes'), {
        titulo,
        conteudo,
        imagemURL,
        autorId: user.uid,
        autorEmail: user.email,
        criadoEm: Timestamp.now(),
      });

      setTitulo('');
      setConteudo('');
      setImagem(null);
      Alert.alert('Sucesso', 'Publicação realizada com sucesso!');
    } catch (err) {
      console.error(err);
      setErro('Erro ao publicar. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Nova Publicação</Text>

      <TextInput
        style={styles.input}
        placeholder="Título"
        value={titulo}
        onChangeText={setTitulo}
      />

      <TextInput
        style={[styles.input, styles.textArea]}
        placeholder="Conteúdo"
        value={conteudo}
        onChangeText={setConteudo}
        multiline
        numberOfLines={6}
      />

      <Button title="Selecionar Imagem" onPress={escolherImagem} />

      {imagem && (
        <Image source={{ uri: imagem }} style={styles.imagemPreview} />
      )}

      {erro !== '' && <Text style={styles.erroTexto}>{erro}</Text>}

      {loading ? (
        <ActivityIndicator size="large" />
      ) : (
        <Button title="Publicar" onPress={handlePublicar} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    padding: 20,
    justifyContent: 'center',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
    color: '#333',
  },
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: '#ccc',
    backgroundColor: '#fff',
    borderRadius: 8,
    marginBottom: 15,
    paddingHorizontal: 12,
  },
  textArea: {
    height: 120,
    textAlignVertical: 'top',
  },
  imagemPreview: {
    width: '100%',
    height: 200,
    marginVertical: 10,
    borderRadius: 10,
  },
  erroTexto: {
    color: 'red',
    marginBottom: 15,
    textAlign: 'center',
  },
});

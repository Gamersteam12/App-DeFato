/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/firebaseConfig`; params?: Router.UnknownInputParams; } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/telaA`; params?: Router.UnknownInputParams; } | { pathname: `/telaB`; params?: Router.UnknownInputParams; } | { pathname: `/telaC`; params?: Router.UnknownInputParams; } | { pathname: `/telaD`; params?: Router.UnknownInputParams; } | { pathname: `/TopDropDownMenu`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/firebaseConfig`; params?: Router.UnknownOutputParams; } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/telaA`; params?: Router.UnknownOutputParams; } | { pathname: `/telaB`; params?: Router.UnknownOutputParams; } | { pathname: `/telaC`; params?: Router.UnknownOutputParams; } | { pathname: `/telaD`; params?: Router.UnknownOutputParams; } | { pathname: `/TopDropDownMenu`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/firebaseConfig${`?${string}` | `#${string}` | ''}` | `/${`?${string}` | `#${string}` | ''}` | `/telaA${`?${string}` | `#${string}` | ''}` | `/telaB${`?${string}` | `#${string}` | ''}` | `/telaC${`?${string}` | `#${string}` | ''}` | `/telaD${`?${string}` | `#${string}` | ''}` | `/TopDropDownMenu${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/firebaseConfig`; params?: Router.UnknownInputParams; } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/telaA`; params?: Router.UnknownInputParams; } | { pathname: `/telaB`; params?: Router.UnknownInputParams; } | { pathname: `/telaC`; params?: Router.UnknownInputParams; } | { pathname: `/telaD`; params?: Router.UnknownInputParams; } | { pathname: `/TopDropDownMenu`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; };
    }
  }
}
